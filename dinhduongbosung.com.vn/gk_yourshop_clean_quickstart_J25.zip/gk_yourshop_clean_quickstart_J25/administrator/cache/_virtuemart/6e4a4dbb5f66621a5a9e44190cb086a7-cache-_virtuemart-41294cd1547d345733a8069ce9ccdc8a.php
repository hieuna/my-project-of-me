<?php die("Access Denied"); ?>#x#a:2:{s:6:"output";s:0:"";s:6:"result";s:200:"<option   value="2">
Air Conditioner</option><option   value="1">
Coffee Machines</option><option   value="3">
Refrigerators</option><option selected=\"selected\"  value="4">
Washing Machines</option>";}
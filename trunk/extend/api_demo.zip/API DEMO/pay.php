<?php
// Thêm class payment
include("class_payment.php");

//Lấy URL trả về từ Soha Payment
$return_url=$_POST["return_url"];
//Lấy thông tin giao dịch
$transaction_info=$_POST["transaction_info"];
//Lấy mã đơn hàng 
$order_code=$_POST["order_code"];
//Lấy email 
$order_email=$_POST["order_email"];
//Lấy mobile 
$order_mobile=$_POST["order_mobile"];
//Lấy tổng số tiền thanh toán tại Soha Payment 
$price=$_POST["price"];

//Khai báo đối tượng của lớp PG_Checkout
$classPayment= new PG_checkout();
//Tạo link thanh toán đến Soha Payment
$url= $classPayment->buildCheckoutUrl($return_url, $transaction_info, $order_code, $price, $order_email, $order_mobile);

header('Location:'.$url);
exit();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Test Payment Gateway</title>
</head>
<body>
	<div align="center" style="height: 40px; line-height:40px; font-size:14px; font-weight:bold; color: red">
		DEMO LẬP TRÌNH THANH TOÁN BẰNG THẺ ĐIỆN THOẠI VÀ THẺ GAME
	</div>
	<?php if (!isset($_POST["order_code"])) : ?>
	<form name="payment" method="post" action="mc_pay.php">
    <table border="1" cellpadding="3" cellspacing="0" style="border-collapse:collapse;" width="800px" align="center">
	    <tr>
			<td align="right"><font color="red">(*)</font> Mã đơn hàng</td>
			<td align="left"><input type="text" value="<?php echo randomcode().'-'.time(); ?>" name="order_code" /><br /><small>(phải duy nhất cho mỗi lần chuyển sang cổng Soha Payment - Max 50 chrs - [A-Za-z0-9._])</small></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Email khách hàng</td>
			<td align="left"><input type="text" value="" name="order_email" /></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Di Động khách hàng</td>
			<td align="left"><input type="text" value="" name="order_mobile" /></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Loại thẻ</td>
			<td align="left">
				<select name="card_type" onchange="javascript:if(this.value=='vcoin'){document.getElementById('cardSeri').style.display='block';}else{document.getElementById('cardSeri').style.display='none';}">
					<option value='vinaphone'>vinaphone</option>
					<option value='mobifone'>mobifone</option>
					<option selected="selected" value='vcoin'>thẻ Vcoin</option>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Số seri</td>
			<td align="left"><input id="cardSeri" type="text" value="" name="card_seri" /></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Mã thẻ</td>
			<td align="left"><input type="text" value="" name="card_code" /><br /><small>(Phải là chữ số, nhiều hơn 11 ký tự)</small></td>
		</tr>
		<tr>
			<td align="right">Thông tin đơn hàng</td>
			<td align="left"><textarea name="transaction_info">Thanh toán [sản phẩm] [trị giá] [tên khách] [mobile]</textarea><br /><small>(Max 500 chrs)</small></td>
		</tr>
		<tr><td colspan="2" align="center"><input type="submit" value="submit" name="submit" /></td></tr>
	</table>
	</form>
	<?php else :
	// Thêm class payment
	include("class_payment.php");
	
	//Lấy thông tin giao dịch
	$transaction_info=$_POST["transaction_info"];
	//Lấy mã đơn hàng 
	$order_code=$_POST["order_code"];
	//Lấy email 
	$order_email=$_POST["order_email"];
	//Lấy mobile 
	$order_mobile=$_POST["order_mobile"];
	//Lấy card_type 
	$card_type=$_POST["card_type"];
	//Lấy card_code 
	$card_code=$_POST["card_code"];
	//Lấy card_seri 
	$card_seri=$_POST["card_seri"];

	//Khai báo đối tượng của lớp PG_Checkout
	$classPayment= new PG_checkout();
	
	$arrReturn = $classPayment->doChargeCard($card_code, $card_type, $transaction_info, $order_code, $order_email, $order_mobile, $card_seri);

	?>
	<table border="1" cellpadding="3" cellspacing="0" style="border-collapse:collapse;" width="800px" align="center">
	    <tr>
			<td align="right"><font color="red"></font> Mã đơn hàng</td>
			<td align="left"><?php echo $arrReturn['order_code']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Tổng giá trị thanh toán</td>
			<td align="left"><?php echo $arrReturn['price']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Thời gian thanh toán</td>
			<td align="left"><?php echo $arrReturn['payment_time']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Thông tin đơn hàng</td>
			<td align="left"><?php echo $arrReturn['transaction_info']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Trạng thái đơn hàng</td>
			<td align="left"><?php echo $arrReturn['response_code']; ?> <i>(1: thanh toán thành công - Khác 1: không thành công)</i></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Kết quả giao dịch</td>
			<td align="left"><?php echo $arrReturn['shp_payment_response_description']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Mô tả kết quả giao dịch</td>
			<td align="left"><?php echo $arrReturn['response_message']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Email</td>
			<td align="left"><?php echo $arrReturn['order_email']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Thông báo lỗi</td>
			<td align="left"><?php echo $arrReturn['error_text']; ?></td>
		</tr>
	</table>
	<?php endif; ?>
</body>
</html>
<?php
	function randomcode($len=5)
	{
		$code = $lchar = NULL;
		for( $i=0; $i<$len; $i++ )
	  	{
		  	$char = chr(rand(48,122));
		  	while( !ereg("[0-9]", $char) )
	    	{
			    if( $char == $lchar ) continue;
			    $char = chr(rand(48,90));
		  	}
		  	$pass .= $char;
		  	$lchar = $char;
		}
		return $pass;
	}
?>

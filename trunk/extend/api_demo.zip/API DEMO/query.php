<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Test Payment Gateway</title>
</head>
<body>
	<div align="center" style="height: 40px; line-height:40px; font-size:14px; font-weight:bold; color: red">
		DEMO LẬP TRÌNH QUERY TRẠNG THÁI CỦA CÁC ĐƠN HÀNG PENDING
	</div>
	<?php if (!isset($_POST['order_code'])) : ?>
	<form name="payment" method="post" action="query.php">
    <table border="1" cellpadding="3" cellspacing="0" style="border-collapse:collapse;" width="800px" align="center">
	    <tr>
			<td align="right"><font color="red">(*)</font> Mã đơn hàng</td>
			<td align="left"><input type="text" value="" name="order_code" /></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Phương thức thanh toán</td>
			<td align="left">
			<select name="payment_method">
				<option value="query">Thẻ Quốc tế và nội địa</option>
				<option value="queryMobileCard">Thẻ cào điện thoại</option>
			</select>
			</td>
		</tr>
		<tr><td colspan="2" align="center"><input type="submit" value="submit" name="submit" /></td></tr>
	</table>
	</form>
	<?php else :
	// Thêm class payment
	include("class_payment.php");
	
	//Khai báo đối tượng của lớp PG_Checkout
	$classPayment= new PG_checkout();
	
	$arrReturn = $classPayment->queryOrderStatus($_POST['order_code'], $_POST['payment_method']);
	?>
	<table border="1" cellpadding="3" cellspacing="0" style="border-collapse:collapse;" width="800px" align="center">
	    <tr>
			<td align="right"><font color="red"></font> Mã đơn hàng</td>
			<td align="left"><?php echo $arrReturn['shp_order_code']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Tổng giá trị đơn hàng</td>
			<td align="left"><?php echo $arrReturn['shp_order_price']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Tổng giá trị thanh toán</td>
			<td align="left"><?php echo $arrReturn['shp_payment_total']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Thời gian thanh toán</td>
			<td align="left"><?php echo $arrReturn['shp_payment_time']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Thông tin đơn hàng</td>
			<td align="left"><?php echo $arrReturn['shp_order_info']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Trạng thái đơn hàng</td>
			<td align="left"><?php echo $arrReturn['shp_order_status']; ?> <i>(1: thanh toán thành công - Khác 1: không thành công)</i></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Kết quả giao dịch</td>
			<td align="left"><?php echo $arrReturn['shp_payment_response_description']; ?></td>
		</tr>
		<tr>
			<td align="right"><font color="red"></font> Mô tả kết quả giao dịch</td>
			<td align="left"><?php echo $arrReturn['shp_payment_response_message']; ?></td>
		</tr>
	</table>
	<?php endif; ?>
</body>
</html>

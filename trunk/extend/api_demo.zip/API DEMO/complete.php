<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Test Payment Gateway</title>
</head>
<body>
<?php
	// Thêm class payment
  	include("class_payment.php");
  	
	//Lấy thông tin chi tiết về lỗi trong quá trình giao dịch
	$error_text=$_GET["error_text"];
	
	//Xử lí đầu vào 
	$pg = new PG_checkout();
	$check = $pg->verifyReturnUrl();
	
	if($check && $error_text=='')	
		$html .="<div align=\"center\">Cám ơn quý khách, quá trình thanh toán đã được hoàn tất. Chúng tôi sẽ kiểm tra và chuyển hàng sớm!</div>";
	elseif ($check)
		$html.="Quá trình thanh toán không thành công do lỗi: ".$error_text."! Bạn vui lòng <a href=\"index.php\">thực hiện lại</a>";
	else
		$html.="Thông tin bảo mật không đúng";
	echo $html;
	
	// Có thể lưu lại 2 thông tin dưới đây: mô tả chi tiết về kết quả thanh toán
	if ($_GET['payment_type']==1) $response_description = $pg->getResponseDescriptionInternational($_GET['response_code']);
	else if ($_GET['payment_type']==2) $response_description = $pg->getResponseDescriptionDomestic($_GET['response_code']);
	$respone_massage = $_GET['response_message'];
	echo $respone_massage;
?>
</body>
</html>
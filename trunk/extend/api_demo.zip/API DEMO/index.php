<?php
	function randomcode($len=8)
	{
		$code = $lchar = NULL;
		for( $i=0; $i<$len; $i++ )
	  	{
		  	$char = chr(rand(48,122));
		  	while( !ereg("[0-9]", $char) )
	    	{
			    if( $char == $lchar ) continue;
			    $char = chr(rand(48,90));
		  	}
		  	$pass .= $char;
		  	$lchar = $char;
		}
		return $pass;
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Test Payment Gateway</title>
</head>
<body>
	<div align="center" style="height: 40px; line-height:40px; font-size:14px; font-weight:bold; color: red">
		DEMO LẬP TRÌNH TÍCH HỢP CỔNG THANH TOÁN TRỰC TUYẾN SOHAPAY VÀO WEBSITE BÁN HÀNG
	</div>
	<div align="center" style="height: 40px; line-height:40px; font-size:16px;">Form hoá đơn bán hàng</div>
	<form name="payment" method="post" action="pay.php">
    <table border="1" cellpadding="3" cellspacing="0" style="border-collapse:collapse;" width="800px" align="center">
	    <tr>
			<td align="right"><font color="red">(*)</font> URL trả về</td>
			<td align="left"><input type="text" value="http://<?php echo $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']; ?>complete.php" name="return_url" /><br /><small>(Max 250 chr)</small></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Mã đơn hàng</td>
			<td align="left"><input type="text" value="<?php echo randomcode(5).'-'.time(); ?>" name="order_code" /> [ORDERID-timestamp] <br /><small>(phải duy nhất cho mỗi lần chuyển sang cổng SohaPay - Max 50 chrs - [A-Za-z0-9._])</small></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Giá trị thanh toán</td>
			<td align="left"><input type="text" value="1000000" name="price" /> VND<br /><small>(chỉ có số)</small></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Email khách hàng</td>
			<td align="left"><input type="text" value="test@email.com" name="order_email" /></td>
		</tr>
		<tr>
			<td align="right"><font color="red">(*)</font> Di Động khách hàng</td>
			<td align="left"><input type="text" value="0900000001" name="order_mobile" /></td>
		</tr>
		<tr>
			<td align="right">Thông tin đơn hàng</td>
			<td align="left"><textarea name="transaction_info">Thanh toán [sản phẩm] [trị giá] [tên khách] [mobile]</textarea><br /><small>(Không chứa ký tự đặc biệt, Max 500 chrs)</small></td>
		</tr>
		<tr><td colspan="2" align="center"><input type="submit" value="submit" name="submit" /></td></tr>
	</table>
	</form>

</body>
</html>
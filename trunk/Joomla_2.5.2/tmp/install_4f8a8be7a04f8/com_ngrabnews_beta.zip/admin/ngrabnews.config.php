<?php
// Email address of the administrator
$admin_email = "nhutcorp@yahoo.com";
$cron_log = 1;
$cron_debug = 0;
$debugfunction = 0;
$debug = 0;
// If your Wrab News Com is behind a proxy, set the following parameters. Otherwise leave blank
// $proxy_Url : The location of the proxy server
// Format : proxy_name_or_ip:proxy_prot
// E.g. : 192.168.1.102:1010
$proxy_Url = '';
// $proxy_UserPwd : Proxy authentication, if required
// Format : username:password
// E.g. : johnd:pass123
$proxy_UserPwd = '';

define("RUNDETAIL_STEP",8);
define("DEFAULT_TAG_ALLOW",'<table><tbody><thead><tfoot><tr><th><td><colgroup><col><p><br><hr><blockquote><b><i><u><sub><sup><strong><em><tt><var><code><xmp><cite><pre><abbr><acronym><address><samp><fieldset><legend><a><img><h1><h2><h3><h4><h4><h5><h6><ul><ol><li><dl><dt><frame><frameset><form><input><select><option><optgroup><button><textarea>');
?>
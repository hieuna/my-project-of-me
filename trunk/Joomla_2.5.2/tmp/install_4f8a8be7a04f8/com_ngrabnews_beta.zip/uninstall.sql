DROP TABLE IF EXISTS 
`#__ngrab_lic`,
`#__ngrab_filter`,
`#__ngrab_cron`,
`#__ngrab_usage`;
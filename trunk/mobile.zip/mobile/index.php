<?php
	include_once 'mobile_device_detect.php';
	mobile_device_detect(true,true,true,true, true, true, true,'http://trungtamdaynghethanhpholaocai.vn/mobile',false);
?>

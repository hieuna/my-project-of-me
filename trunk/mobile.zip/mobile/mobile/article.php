<?php 
include_once '../config.php'; 
include_once '../lib/function.php'; 
include_once  ADMIN . DS . "services/articleservices.php"; 

$cat_id = $_GET['cat_id']; 
$article_id = $_GET['article_id']; 
$articleservices = new ArticleServices();
$articles = $articleservices->getArticlesByCategoryArticle($cat_id, $article_id);

include('views/article.tmpl.php'); 
?>



﻿<?php include('includes/header.php'); ?> 
<?php include_once '../config.php'; ?>
<?php include_once '../lib/function.php'; ?>
<?php include_once  ADMIN . DS . "services/articleservices.php"; ?>
<body>
 <div data-role="page">
   <header data-role="header" class="tuts">
     <h1>
       <!--<img src="img/TLogo.png" alt="Tuts+" />-->
	   Trung tâm dạy nghề thành phố lào cai
     </h1>
   </header>
   <!-- /header -->

   <div data-role="content">
	<?php 
		$articleservices = new ArticleServices();
		$id = 1;
		$articles = $articleservices->getArticlesByCategory($id, 20);
		?>
     <ul data-role="listview" data-theme="c" data-dividertheme="d" data-counttheme="e">
	 <?php foreach ($articles as $article) :?>
       <li>
		<?php if ($article['image']) : ?>
         <img src="<?php if ($article['source'] == 1) : ?><?php echo $article['image']; ?><?php else: ?><?php echo DOMAIN . $article['image']; ?><?php endif; ?>" alt="<?php echo $article['title']; ?>" class="ui-li-icon" />
		 <?php endif; ?>
         <a href="article.php?cat_id=<?php echo $id; ?>&article_id=<?php echo $article['articles_id']; ?>"> <?php echo $article['title']; ?> </a>
       </li>
	   <?php endforeach; ?>
     </ul>
   </div>

   <footer data-role="footer" class="tuts">
      <h4> &copy; Copyright chieund.fat@gmail.com </h4>
   </footer>

 </div>
 <!-- /page -->
</body>
</html>


﻿<?php include('includes/header.php'); ?>
<body> 

<div data-role="page">
   <header data-role="header">
      <h1> Trung tâm dạy nghề thành phố lào cai </h1>
   </header><!-- /header -->

   <div data-role="content">	
        <h1 style="margin-bottom: 10px"> <?php echo $articles['title']; ?> </h1>
        <div> <b><?php echo post_db_parse_html($articles['description']); ?></b> </div>
		<div> <?php echo post_db_parse_html($articles['content']); ?> </div>
   </div><!-- /content -->

   <footer data-role="footer" data-position="fixed">
      <h4> &copy; Copyright chieund.fat@gmail.com </h4>
   </footer>
</div><!-- /page -->
</body>
</html>



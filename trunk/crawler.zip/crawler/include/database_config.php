<?php
/*$database_host = 'localhost';
$database_username = 'root';
$database_password = 'vertrigo';
$database_name = 'tindiem';*/

$database_host = 'localhost';
$database_username = 'root';
$database_password = 'vertrigo';
$database_name = 'tintuc';
?>
<ul>
<li><a href="index.php?option=com_adsmanager&c=tools&task=installjoomfish"><?php echo JText::_('ADSMANAGER_INSTALL_JOOMFISH');?></a></li>
<?php /*<li><a href="index.php?option=com_adsmanager&c=tools&task=installsef"><?php echo JText::_('ADSMANAGER_INSTALL_SEF');?></a></li>*/?>
</ul>
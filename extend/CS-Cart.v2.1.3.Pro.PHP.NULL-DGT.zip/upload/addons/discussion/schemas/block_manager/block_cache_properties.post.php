<?php
/***************************************************************************
*                                                                          *
*    Copyright (c) 2004 Simbirsk Technologies Ltd. All rights reserved.    *
*                                                                          *
* This  is  commercial  software,  only  users  who have purchased a valid *
* license  and  accept  to the terms of the  License Agreement can install *
* and use this program.                                                    *
*                                                                          *
****************************************************************************
* PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
* "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
****************************************************************************/


//
// $Id: block_cache_properties.post.php 10963 2010-10-20 10:59:40Z klerik $
//

if ( !defined('AREA') ) { die('Access denied'); }

$schema['data_functions']['_STATIC_TEMPLATE_BLOCK_']['templates']['addons/discussion/blocks/testimonials.tpl'] = array (
	'update_handlers' => array ('discussion_messages'),
);

?>
<?php
/***************************************************************************
*                                                                          *
*    Copyright (c) 2004 Simbirsk Technologies Ltd. All rights reserved.    *
*                                                                          *
* This  is  commercial  software,  only  users  who have purchased a valid *
* license  and  accept  to the terms of the  License Agreement can install *
* and use this program.                                                    *
*                                                                          *
****************************************************************************
* PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
* "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
****************************************************************************/


//
// $Id: func.php 11675 2011-01-24 07:42:24Z andyye $
//

if ( !defined('AREA') ) { die('Access denied'); }

function fn_catalog_mode_enabled($company_id)
{
	if (PRODUCT_TYPE == 'MULTIVENDOR') {
		if (empty($company_id)) {
			return Registry::get('addons.catalog_mode.main_store_mode') == 'catalog' ?  'Y' : 'N';
		} else {
			// check if the current vendor is running in the catalog mode
			static $vendors_cache = array();

			if (isset($vendors_cache[$company_id])) {
				return $vendors_cache[$company_id];
			} else {
				$vendors_cache[$company_id] = db_get_field("SELECT catalog_mode FROM ?:companies WHERE company_id = ?s", $company_id);
				return $vendors_cache[$company_id];
			}
		}
	}

	return 'Y';
}

function fn_catalog_mode_may_disable_minicart()
{
	if (PRODUCT_TYPE == 'MULTIVENDOR') {
		if (Registry::get('addons.catalog_mode.main_store_mode') == 'store' || Registry::get('addons.catalog_mode.add_to_cart_empty_buy_now_url') == 'Y') {
			return 'N';
		}
		if (db_get_field("SELECT COUNT(*) FROM ?:companies WHERE catalog_mode = 'N'")) {
			return 'N';
		}
	}

	return Registry::get('addons.catalog_mode.add_to_cart_empty_buy_now_url') == 'Y' ? 'N' : 'Y';
}

function fn_is_add_to_cart_allowed($product_id)
{
	// No need to involve heavy SQL requests performed by fn_get_products()
	if (Registry::get('addons.catalog_mode.add_to_cart_empty_buy_now_url') == 'Y' && db_get_field("SELECT buy_now_url FROM ?:products WHERE product_id = ?i", $product_id) == '') {
		return true;
	}

	return false;
}

function fn_catalog_mode_pre_add_to_cart($product_data, $cart, $auth, $update)
{
	if (AREA == 'C') {
		// Firebug protection
		if (PRODUCT_TYPE == 'MULTIVENDOR') {
			foreach ($product_data as $key => &$product) {
				$product_id = (!empty($product['product_id'])) ? $product['product_id'] : $key;
				$company = fn_get_company_by_product_id($product_id);

				if (!isset($company['company_id'])) {
					$company['company_id'] = 0;
				}

				if (fn_catalog_mode_enabled($company['company_id']) == 'Y' && !fn_is_add_to_cart_allowed($product_id)) {
					$product = array();
				}
			}
		} else {
			foreach ($product_data as $key => &$product) {
				$product_id = (!empty($product['product_id'])) ? $product['product_id'] : $key;
				if (!fn_is_add_to_cart_allowed($product_id)) {
					$product = array();
				}
			}
		}
	}
}

?>

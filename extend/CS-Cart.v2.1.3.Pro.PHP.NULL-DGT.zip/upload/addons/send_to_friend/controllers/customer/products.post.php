<?php
/***************************************************************************
*                                                                          *
*    Copyright (c) 2009 Simbirsk Technologies Ltd. All rights reserved.    *
*                                                                          *
* This  is  commercial  software,  only  users  who have purchased a valid *
* license  and  accept  to the terms of the  License Agreement can install *
* and use this program.                                                    *
*                                                                          *
****************************************************************************
* PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
* "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
****************************************************************************/


//
// $Id: products.post.php 8049 2009-10-02 10:24:55Z lexa $
//

if ( !defined('AREA') ) { die('Access denied'); }

if (!empty($_SESSION['saved_post_data']['send_data'])) {
	$view->assign('send_data', $_SESSION['saved_post_data']['send_data']);
	unset($_SESSION['saved_post_data']['send_data']);
}


?>

			</td>
		</tr>
	</table>

	<a name="foot"></a>
	<div class="wm_copyright" id="copyright">
<?php
	@require('inc.footer.php');
?>
	</div>
</div>
</body>
</html>
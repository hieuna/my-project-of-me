For installation instructions, open /web/help/default.htm file and then click "Installation Instructions" in the contents.
